To run this example double click on data receiver jar or use java -jar command.
This example accepts arguments. Please run it with -h option to read the usage.


For Windows 32 bit systems.

This example has rxtxSerial.dll for 64 bit systems, if yours is a 32 bit system replace this dll
with the right one that you can find in winDLLs folder.