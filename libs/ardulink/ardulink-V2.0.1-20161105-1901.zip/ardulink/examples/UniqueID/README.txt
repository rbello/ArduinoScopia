To run this example double click on unique id jar or use java -jar command.

It's a shell application without a GUI.