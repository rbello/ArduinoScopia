To run this example double click on button quest jar or use java -jar command.
